import { Injectable } from '@angular/core';
import{Http, Response, Headers, RequestOptions} from '@angular/http';
import{Observable}   from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { EmployeeDetails } from 'src/classes/EmployeeDetails';
import { error } from 'protractor';

@Injectable({
  providedIn: 'root'
})
export class AdminstaffserviceService {

  private baseUrl:string='http://localhost:8080/';
  private headers = new Headers({'Content-Type':'application/json'});
  private options = new RequestOptions({headers:this.headers});

  constructor(private _http:Http) { }
  findEmployee(emp_id){
    return this._http.get(this.baseUrl+"findEmployee/"+emp_id,this.options).map((response:Response)=>response.json()).catch(this.errorHandler)
  }
  errorHandler(error:Response){

    return Observable.throw(error||"SERVER ERROR");
 }
 submitAttendance(emp_id,status){
   return this._http.get(this.baseUrl+"submitAttendance/"+emp_id+"/"+status,this.options).map((response:Response)=>response.json()).catch(this.errorHandler);
 }
 lop(emp_id){
   return this._http.get(this.baseUrl+"lop/"+emp_id,this.options).map((response:Response)=>response.json()).catch(this.errorHandler);
 }
 allEmployeesLops(){
   return this._http.get(this.baseUrl+"allEmployeesLops",this.options).map((response:Response)=>response.json()).catch(this.errorHandler);
 }

}
