import { Injectable } from '@angular/core';
import { EmployeeDetails } from 'src/classes/EmployeeDetails';

@Injectable({
  providedIn: 'root'
})
export class UtilityserviceService {
   empd=new EmployeeDetails();
  constructor() { }
  setEmployeeDetails(emp){
         this.empd=emp;
         console.log(this.empd);
  }
  getEmployeeDetails(){
         return this.empd;
  }
}
