import { TestBed } from '@angular/core/testing';

import { AdminstaffserviceService } from './adminstaffservice.service';

describe('AdminstaffserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdminstaffserviceService = TestBed.get(AdminstaffserviceService);
    expect(service).toBeTruthy();
  });
});
