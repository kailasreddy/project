import { Component, OnInit } from '@angular/core';
import { EmployeeDetails } from 'src/classes/EmployeeDetails';
import { UtilityserviceService } from 'src/app/services/utilityservice.service';
import * as CanvasJS from '../../canvasjs.min';
import { EmployeeserviceService } from 'src/app/services/employeeservice.service';
import { type } from 'os';
import { Attendance } from 'src/classes/Attendance';
import {ActivatedRoute, Params, Router } from '@angular/router';
@Component({
  selector: 'app-employeehomepage',
  templateUrl: './employeehomepage.component.html',
  styleUrls: ['./employeehomepage.component.css']
})
export class EmployeehomepageComponent implements OnInit {
  
   emp_id;
   name;
   empd=new EmployeeDetails();
   attendances;
   lop;
   datee;
   leaves;
   
   leaveStatus="";
   showAttendanceStatus="false";
   showLopStatus="false";
   showApplyLeave="false";
   showAvailableLeaves="false";
 

    dataPoints=[{label:"Jan",y:0},{label:"Feb",y:0},{label:"Mar",y:0},{label:"Apr",y:0},{label:"May",y:0},{label:"Jun",y:0},{label:"Jul",y:0},{label:"Aug",y:0},{label:"Sep",y:0},
    {label:"Oct",y:0},{label:"Nov",y:0},{label:"Dec",y:0}]
  constructor(private utilityService:UtilityserviceService,private employeeService:EmployeeserviceService,private router:Router) { }

  ngOnInit() {
     let count=0;
    this.leaveStatus="";
    console.log(this.dataPoints);
    this.emp_id=sessionStorage.getItem("emp_id");
    this.name=sessionStorage.getItem("name");
    this.employeeService.attendancePercentages(this.emp_id).subscribe((data)=>{
      for (var i = 1; i <= data.length; i++) {
           this.dataPoints[i-1].y=data[i-1];
            
      }
       
    })
    console.log(this.dataPoints);
       console.log("sop");
		let chart = new CanvasJS.Chart("chartContainer",{
      
			 animationEnabled: true,
			title:{
				text: "Attendance BarGraph"
      },
      axisY:{
         maximum:100
      },
			data: [{
				type: "column",
				dataPoints :this.dataPoints
			}]
		});
    chart.render();
 
   
    this.empd=this.utilityService.getEmployeeDetails();
    console.log(this.empd);

  
  }
  viewAttendance(){
    this.showAttendanceStatus="true";
    this.showLopStatus="false";
    this.showApplyLeave="false";
    this.showAvailableLeaves="false";
       this.employeeService.viewAttendance(this.emp_id).subscribe((data)=>{
             this.attendances=data;
             console.log(this.attendances);
       })
  }
  checkLop(){
    this.showAttendanceStatus="false";
    this.showLopStatus="true";
    this.showApplyLeave="false";
    this.showAvailableLeaves="false";
    this.employeeService.checkLop(this.emp_id).subscribe((data)=>{
       this.lop=data;
       console.log(this.lop);
    })
  }
  applyLeave(){
    this.showAttendanceStatus="false";
    this.showLopStatus="false";
    this.showApplyLeave="true";
    this.showAvailableLeaves="false";
  }
  submitDate(){
     
    let newDate = new Date(this.datee);
    console.log(newDate);
    console.log(typeof this.datee);
     console.log(this.datee);
   
    let day=newDate.getDate();
    let month=newDate.getMonth()+1;
    let year=newDate.getFullYear();
    console.log(day+" "+month+" "+year);
    let attendance=new Attendance();
    attendance.day=day;
    attendance.month=month;
    attendance.year=year;
    attendance.status="leave";
    this.employeeService.applyLeave(this.emp_id,attendance).subscribe((data)=>{
      console.log(data);
      this.leaveStatus=data;
    })
    
  }
  checkAvailableLeaves(){
    this.showAttendanceStatus="false";
    this.showLopStatus="false";
    this.showApplyLeave="false";
    this.showAvailableLeaves="true";
      this.employeeService.leaves(this.emp_id).subscribe((data)=>{
        this.leaves=data;
      })
  }
  
  logout(){
    this.emp_id=sessionStorage.removeItem("emp_id");
     this.emp_id=null;
     this.router.navigateByUrl("/home");
  }
  abc(){

  }

}
