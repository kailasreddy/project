import { Component, OnInit,ViewChild } from '@angular/core';
import { AdminserviceService } from '../../services/adminservice.service';
import { error } from 'util';
import { EmployeeDetails } from 'src/classes/EmployeeDetails';
import {NgForm} from '@angular/forms';
import { EmployeeLogin } from 'src/classes/EmployeeLogin';
@Component({
  selector: 'app-admin-home-page',
  templateUrl: './admin-home-page.component.html',
  styleUrls: ['./admin-home-page.component.css']
})
export class AdminHomePageComponent implements OnInit {
  @ViewChild('f',{static: false}) signupForm:NgForm;
  searchText;
  constructor(private _adminService:AdminserviceService) { }
    ListEmployees:EmployeeDetails[]=[];
    addEmployeeStatus="false";
    emp_id;
    name;
    page:number=0;
    employeeDetails:Array<EmployeeDetails>;
    pages:Array<number>;
  ngOnInit() {
    this.addEmployeeStatus="false";
    this.emp_id=sessionStorage.getItem("emp_id");
    this.name=sessionStorage.getItem("name");
    console.log(this.emp_id);
    // this._adminService.getAllEmployees().subscribe((data)=>{
    //  this.ListEmployees=data;
    //  console.log(data);
    //  console.log(this.ListEmployees);
    // },error=>{
    //   console.log(error);
    // })
       this._adminService.getAllEmployeesData(this.page).subscribe((empd)=>{
         this.employeeDetails=empd['content'];
         console.log(this.employeeDetails);
         this.pages=new Array(empd['totalPages']);
         
       },(error)=>{ console.log(error.error.message);})

  }
  setPage(i,event:any){
    event.preventDefault();
         this.page=i;
         this.ngOnInit();
  }
  
  delete(emp_id){
    console.log(emp_id);
     var v=confirm("Are u sure?");
     if(v==true){
       ("ok");
       this._adminService.deleteEmployee(emp_id).subscribe((data)=>{
        console.log(data);
        this.ngOnInit();
      })
      
     }
   
  }
  addEmployee(){
    this.addEmployeeStatus="true";

  }
  processForm(){
    console.log(this.signupForm.value);
    let emp=new EmployeeDetails();
    emp.name=this.signupForm.value.employeeData.name;
    console.log(emp.name);
    emp.designation=this.signupForm.value.employeeData.designation;
    emp.reportingTo=this.signupForm.value.employeeData.reportingTo;
    emp.userType=this.signupForm.value.employeeData.userType;
    emp.address=this.signupForm.value.employeeData.address;
    emp.gender=this.signupForm.value.employeeData.gender;
    emp.yearsOfService=this.signupForm.value.employeeData.yearsOfService;
    emp.bankAccount=this.signupForm.value.employeeData.bankAccount;
    emp.ctc=this.signupForm.value.employeeData.ctc;
    emp.leaves=this.signupForm.value.employeeData.leaves;
    console.log(emp);
    this._adminService.addEmployee(emp).subscribe((data)=>{
      console.log(data);
      alert(emp.userType+" Added Successfully...");
      this.addEmployeeStatus="false";
      this.ngOnInit();

    })
  }
  

  logout(){
    this.emp_id=sessionStorage.removeItem("emp_id");
   this.emp_id=null;
   

  }

}
