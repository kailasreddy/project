import { Component, OnInit, ViewChild } from '@angular/core';
import { AdminserviceService } from 'src/app/services/adminservice.service';
import { NgForm } from '@angular/forms';
import {ActivatedRoute, Params, Router } from '@angular/router';
import { EmployeeDetails } from 'src/classes/EmployeeDetails';
import { UtilityserviceService } from 'src/app/services/utilityservice.service';
@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent {
  title = 'EmployeeAttendanceMonitoring';
  @ViewChild('f',{static: false}) signupForm:NgForm;
  loginStatus="true";
  errorMessage="Invalid login details";
  constructor(private adminService:AdminserviceService,private router:Router,private utilityService:UtilityserviceService){

  }
  // private gridApi;
  // private gridColumnApi;
  // private columnDefs;
  // private sortingOrder;
  // constructor(){
  //   this.columnDefs=[
  //     {
  //       headerName:"Name",
  //       field:"firstName",
  //       width:150,
  //       sortingOrder:["asc","desc"]
  //     },
  //     {
  //       headerName:"age",
  //       field:"age",
  //       width:50,

  //     }
  //   ]
  // }
  // onGridReady(params){
  //   this.gridApi=params.api;
  //   this.gridColumnApi=params.gridColumnApi;
  //   let dataValue=[{"firstName":"Gourab","age":22}]
  //   params.api.setRowData(dataValue);
  // }
  onSubmit(){
    console.log(this.signupForm.value);
    let emp_id=this.signupForm.value.userData.userId;
    console.log();
    let userType=this.signupForm.value.userData.userType;
    let pass=this.signupForm.value.userData.password;
    console.log(pass);
    this.adminService.loginValidation(emp_id,userType,pass).subscribe((data)=>{
       console.log(data.emp_id);
      if(+data.emp_id==0){
        console.log("skj");
                this.loginStatus="false";
      }
      else{
           console.log("djfkdj");
           this.loginStatus="true";
           sessionStorage.setItem("name",data.name);
           this.utilityService.setEmployeeDetails(data);
          sessionStorage.setItem("emp_id",data.emp_id);
          if(data.userType==="Employee")
          {
          return this.router.navigate(['/employee']);
          }
          else if(data.userType==="AdminStaff"){
            return this.router.navigate(['/adminStaff'])
          }
          else if(data.userType==="Admin")
          {
            console.log("djfkd");
            return this.router.navigate(['/admin']);
          }
          else{

          }
      }
    })
  }


}
