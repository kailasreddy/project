import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminstaffhomepageComponent } from './adminstaffhomepage.component';

describe('AdminstaffhomepageComponent', () => {
  let component: AdminstaffhomepageComponent;
  let fixture: ComponentFixture<AdminstaffhomepageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminstaffhomepageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminstaffhomepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
