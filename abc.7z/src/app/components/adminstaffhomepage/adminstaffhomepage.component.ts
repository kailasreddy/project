import { Component, OnInit } from '@angular/core';
import { EmployeeDetails } from 'src/classes/EmployeeDetails';
import { AdminstaffserviceService } from 'src/app/services/adminstaffservice.service';
import { stat } from 'fs';

@Component({
  selector: 'app-adminstaffhomepage',
  templateUrl: './adminstaffhomepage.component.html',
  styleUrls: ['./adminstaffhomepage.component.css']
})
export class AdminstaffhomepageComponent implements OnInit {
  emp_id;
  name;
  id;
  employee=new EmployeeDetails();
  lop;
  lopStatus="false";
  employeesLops;
  employeesLopsStatus="false";
  constructor(private adminStaffService:AdminstaffserviceService) { }
  status="present";
  ngOnInit() {
    this.emp_id=sessionStorage.getItem("emp_id");
    this.name=sessionStorage.getItem("name");
    console.log(this.emp_id);
  }
  findEmployee(){
    this.employeesLopsStatus="false";
    this.lopStatus="false";
    console.log(this.id);
    this.adminStaffService.findEmployee(this.id).subscribe((data)=>{
      console.log(data);
      this.employee=data;
      console.log(this.employee);
    })
    
  }
  submitAttendance(emp_id,status){
    console.log(emp_id);
    console.log(status);
    this.adminStaffService.submitAttendance(emp_id,status).subscribe((data)=>{
      console.log(data);
    })

  }
  lossOfPay(){
    this.employeesLopsStatus="false";
    this.lopStatus="true";
    console.log(this.id);
    this.adminStaffService.lop(this.id).subscribe((data)=>{
      console.log(data);
      this.lop=data;
    })
  }
  allEmployeesLops(){
    this.employeesLopsStatus="true";
    this.lopStatus="false";
    this.adminStaffService.allEmployeesLops().subscribe((data)=>{
      console.log(data);
      this.employeesLops=data;
    })
  }
  logout(){
    this.emp_id=sessionStorage.removeItem("emp_id");
   this.emp_id=null;
  }

}
