import { EmployeeLogin } from './EmployeeLogin';
import { Attendance } from './Attendance';
import { Salary } from './Salary';

export class EmployeeDetails{
    emp_id;string;
    name:string;
    designation:string;
    reportingTo:string;
    userType:string;
    address:string;
    gender:string;
    yearsOfService:string;
    bankAccount:number;
    ctc:number;
    leaves:number;
    empLoginDetails:EmployeeLogin;
    attendances:Attendance[];
    salary:Salary;
}