import { EmployeeDetails } from './EmployeeDetails';

export class Attendance{
    attendanceId:number;
    day:number;
    month:number;
    year:number;
    status:string;
    employeeDetails:EmployeeDetails;
}