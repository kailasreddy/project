import { NumberFilter } from 'ag-grid-community';

export class Salary{
    salary_id:number;
    month:number;
    year:number;
    grossSalary:number;
    lop:number;
    otherTaxes:number;
    netSalary:number;
    totalSalary:number;
    pf:number;
}