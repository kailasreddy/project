export class EmployeeLogin{
     emp_id:number;
     password:number;
     role:string;
}