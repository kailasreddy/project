package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.PathVariable;

import com.example.entities.Attendance;
import com.example.entities.EmployeeDetails;
import com.example.entities.EmployeeExcel;

public interface EmployeeDetailsService {
	public EmployeeDetails addEmployee(EmployeeDetails emp);
	public List<EmployeeDetails> getAllEmployees();
	public int deleteEmployee(long emp_id);
	public Optional<EmployeeDetails> findEmployee(long emp_id);
	public int submitAttendance(long emp_id,String status);
	public float lop(long emp_id);
	public EmployeeDetails loginValidation(long emp_id,String userType,String password);
	public List<Attendance> viewAttendance(long emp_id);
	public String applyLeave(long emp_id,Attendance att);
	public int leaves(long emp_id);
	public List<Integer> attendancePercentage(long emp_id);
	public List<EmployeeExcel> allEmployeesLops();
}   
