package com.example.service;

import java.io.FileOutputStream;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entities.Attendance;
import com.example.entities.EmployeeDetails;
import com.example.entities.EmployeeExcel;
import com.example.entities.EmployeeLogin;
import com.example.entities.Salary;
import com.example.repositories.AttendanceRepositoy;
import com.example.repositories.EmployeeDetailsRepository;
import com.example.repositories.EmployeeLoginRepository;
import com.example.repositories.SalaryRepositoy;

@Service
public class EmployeeDetailsImplService implements EmployeeDetailsService {
	 @Autowired
     EmployeeDetailsRepository employeeDetailsRepository;
	 @Autowired
	 AttendanceRepositoy attendanceRepository;
	 @Autowired
	 EmployeeLoginRepository employeeLoginRepository;
	 @Autowired 
	 SalaryRepositoy salaryRepository;
	
	@Override
	public EmployeeDetails addEmployee(EmployeeDetails emp) {
		 
		Date date=new Date();
		int day=date.getDate();
		int month=date.getMonth();
		int year=date.getYear();
		System.out.println(day);
		System.out.println(month+1);
		System.out.println(year+1900);
		String status="present";
		 
	     float grossSalary=emp.getCtc()/12;
	     float otherTaxes=(5*grossSalary)/100;
	     float pf=(12*grossSalary)/100;
	     float netSalary=grossSalary-otherTaxes-pf;
	     YearMonth yearMonthObject = YearMonth.of(year+1900, month+1);
	     int daysInMonth = yearMonthObject.lengthOfMonth(); 
	     System.out.println(daysInMonth);
	     float oneDaySalary=netSalary/daysInMonth;
	     float lop=0;
	    if(day==1) {
	    	lop=0;
	    }
	    else
	    {
	    	lop=oneDaySalary*(day-1);
	    }
	    float totalSalary=netSalary-lop;
	    Salary salary=new Salary(month+1,year+1900,grossSalary,lop,otherTaxes,netSalary,totalSalary,pf);
	    emp.setSalary(salary);
	    
	    Attendance att=new Attendance(day,month+1,year+1900,status,emp);
	    Attendance att2=new Attendance(day,month+1,year+1900,status,emp);
		List<Attendance> listAtt=new ArrayList<Attendance>();
		listAtt.add(att);
		//listAtt.add(att2);
		emp.setAttendances(listAtt);
		emp.setEmpLoginDetails(new EmployeeLogin("abc", emp.getUserType()));
	    EmployeeDetails empo=employeeDetailsRepository.save(emp);
	    
		return empo;
		
//		System.out.println("system"+emp.getCtc());
//		
//		EmployeeDetails empo= employeeDetailsRepository.save(emp);
//		if(empo==null)
//		{
//			return null;
//		}
//		else 
//		{
//			return empo;
//		}
//		
	}

	@Override
	public List<EmployeeDetails> getAllEmployees() {
		 return employeeDetailsRepository.findAll();
		
	}

	@Override
	public int deleteEmployee(long emp_id) {
		employeeDetailsRepository.deleteById(emp_id);
		return 1;
	}

	@Override
	public Optional<EmployeeDetails> findEmployee(long emp_id) {
	  Optional<EmployeeDetails> emp=employeeDetailsRepository.findById(emp_id);
	  if(emp==null)
	  {
		  return null;
	  }
	  else
	  {
		  return emp;
	  }
	}

	@Override
	public int submitAttendance(long emp_id, String status) {
		 EmployeeDetails emp=employeeDetailsRepository.getOne(emp_id);
		   List<Attendance> atList=emp.getAttendances();
		   Date date=new Date();
			int day=date.getDate();
			int month=date.getMonth()+1;
			int year=date.getYear()+1900;
			Attendance at=new Attendance();
			at.setDay(day);
			at.setMonth(month);
			at.setYear(year);
			at.setStatus(status);
			at.setEmployeeDetails(emp);
			atList.add(at);
			emp.setAttendances(atList);
			employeeDetailsRepository.save(emp);
			return 1;
		   
	}

	@Override
	public float lop(long emp_id) {
		  Date date=new Date();
			int month=date.getMonth()+1;
			int year=date.getYear()+1900;
		List<Attendance> atList=attendanceRepository.employeeAttendance(emp_id, month, year);
		 System.out.println(atList);
		 int count=0;
		 for(Attendance at:atList)
		 {
			 if(at.getStatus().equals("absent")) {
				 count=count+1;
			 }
			 System.out.println(at.getDay()+""+at.getStatus());
		 }
		 EmployeeDetails emp=employeeDetailsRepository.getOne(emp_id);
		 Salary salary=emp.getSalary();
		 float netSalary=salary.getNetSalary();
		 float totalSalary=salary.getTotalSalary();
		
		 YearMonth yearMonthObject = YearMonth.of(year, month);
	     int daysInMonth = yearMonthObject.lengthOfMonth(); 
	     System.out.println(daysInMonth);
	     float oneDaySalary=netSalary/daysInMonth;
	     float lop=salary.getLop();
	     lop=lop+(oneDaySalary*count);
	     System.out.println(" dfd"+oneDaySalary);
	     System.out.println(lop);
		 totalSalary=netSalary-lop;
//		 salary.setLop(lop);
		 salary.setTotalSalary(totalSalary);
		 emp.setSalary(salary);
		    employeeDetailsRepository.save(emp);
		    return lop;
		
	}

	@Override
	public EmployeeDetails loginValidation(long emp_id, String userType, String password) {
		
		EmployeeDetails empd=new EmployeeDetails();	
		  try {
			EmployeeDetails emp=employeeDetailsRepository.findById(emp_id).get();
				if(emp_id==emp.getEmp_id() && userType.equals(emp.getUserType()) && password.equals(emp.getEmpLoginDetails().getPassword())) {
				   empd=emp;
				}
				
		  }
		  catch(Exception ex) {
			  
		  }
		  return empd;
	}

	@Override
	public List<Attendance> viewAttendance(long emp_id) {
		List<Attendance> atList=new ArrayList<Attendance>();
		 Date date=new Date();
			int month=date.getMonth()+1;
			int year=date.getYear()+1900;
		try {
			atList=attendanceRepository.employeeAttendance(emp_id, month, year);
		      
		}
		catch(Exception ex){
			
		}
		return atList;
		
	}

	@Override
	public String applyLeave(long emp_id, Attendance att) {
		try {
		
		 EmployeeDetails empd=employeeDetailsRepository.findById(emp_id).get();
		 if(empd.getLeaves()<1) {
			 return "fail";
		 }
		 int day1=att.getDay();
		 int month1=att.getMonth();
		 int year1=att.getYear();
		 Date date=new Date();
		    int day=date.getDate();
			int month=date.getMonth()+1;
			int year=date.getYear()+1900;
			
		  if(day1>day && month1>=month && year1>=year) {
			  
		  }
		  else
		  {
			  return "invalidDate";
		  }
		 List<Attendance> atList=empd.getAttendances();
		   empd.setLeaves(empd.getLeaves()-1);
		  att.setEmployeeDetails(empd);
		  atList.add(att);
		  empd.setAttendances(atList);
		  employeeDetailsRepository.save(empd);
		  return "success";
		}
		catch(Exception ex) {
			return "serverError";
		}
		  
	}

	@Override
	public int leaves(long emp_id) {
		int leaves=-1;
		try {
			  leaves=employeeDetailsRepository.findById(emp_id).get().getLeaves();
			  return leaves;
		}
		catch(Exception ex)
		{
			return leaves;
		}
		
	}

	@Override
	public List<Integer> attendancePercentage(long emp_id) {
		List<Integer> totalAttendance=new ArrayList<Integer>();
		 Date date=new Date();
		    int day=date.getDate();
			int month=date.getMonth()+1;
			int year=date.getYear()+1900;
			for(int i=1;i<=month;i++) {
				List<Attendance> atList=attendanceRepository.employeeAttendance(emp_id, i, year);
				int count=0;
				for(Attendance at :atList) {
					if(at.getStatus().equals("absent")) {
						count=count+1;
					}
				}
				 YearMonth yearMonthObject = YearMonth.of(year, i);
			     int daysInMonth = yearMonthObject.lengthOfMonth(); 
			     int absentPercentage=(count*100)/daysInMonth;
			     int presentPercentage=100-absentPercentage;
			      totalAttendance.add(presentPercentage);
			}
		
	   return totalAttendance;
	}

	@Override
	public List<EmployeeExcel> allEmployeesLops() {
		List<EmployeeExcel> empXLObjs=new ArrayList<EmployeeExcel>();
		XSSFWorkbook workbook=new XSSFWorkbook();
		Sheet sheet=workbook.createSheet();
		String excelFilePath="C:/Users/ssrikail/Desktop/empLop.XLSX";
		int rowCount=1;
		Row row1=sheet.createRow(1);
		Cell cell1=row1.createCell(1);
		cell1.setCellValue("EmployeeId");
		Cell cell2=row1.createCell(2);
		cell2.setCellValue("Name");
		Cell cell3=row1.createCell(3);
		cell3.setCellValue("LOP");
		Cell cell4=row1.createCell(4);
		cell4.setCellValue("salary");
		List<EmployeeDetails> empList=employeeDetailsRepository.findAll();
		for(EmployeeDetails empd: empList) {
			Row row=sheet.createRow(++rowCount);
			EmployeeExcel obj=writeLops(empd,row);
			empXLObjs.add(obj);
		}
		try{
			FileOutputStream outputStream=new FileOutputStream(excelFilePath);
			workbook.write(outputStream);
		}
		catch(Exception ex){
			
		}
		return empXLObjs;
	}
	
	private EmployeeExcel writeLops(EmployeeDetails empd,Row row){
	
		long emp_id=empd.getEmp_id();
		String name=empd.getName();
		float lop=lop(empd.getEmp_id());
		float salary=empd.getSalary().getTotalSalary();
		EmployeeExcel empObj=new EmployeeExcel(emp_id,name,lop,salary);
		
		Cell cell1=row.createCell(1);
		cell1.setCellValue(emp_id);
		Cell cell2=row.createCell(2);
		cell2.setCellValue(name);
		Cell cell3=row.createCell(3);
		cell3.setCellValue(lop);
		Cell cell4=row.createCell(4);
		cell4.setCellValue(salary);
		return empObj;
	}
	
   
}
