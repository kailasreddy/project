package com.example.entities;

public class EmployeeExcel {
	private long emp_id;
	private String name;
	private float lop;
	private float salary;
	public EmployeeExcel() {
		
	}
	public EmployeeExcel(long emp_id, String name, float lop, float salary) {
		super();
		this.emp_id = emp_id;
		this.name = name;
		this.lop = lop;
		this.salary = salary;
	}
	public long getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(long emp_id) {
		this.emp_id = emp_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getLop() {
		return lop;
	}
	public void setLop(float lop) {
		this.lop = lop;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	
	

}
