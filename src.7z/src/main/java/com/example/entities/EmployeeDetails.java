package com.example.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties  
public class EmployeeDetails {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
private long emp_id;
private String name;
private String designation;
private String reportingTo;
private String userType;
private String address;
private String gender;
private String yearsOfService;
private long bankAccount;
private long ctc;
private int leaves;
@OneToOne(cascade=CascadeType.ALL)
private EmployeeLogin empLoginDetails;

@OneToMany(mappedBy = "employeeDetails",cascade = CascadeType.ALL)
private List<Attendance> attendances;
@OneToOne(cascade=CascadeType.ALL)
private Salary salary;


public EmployeeDetails() {

}






public EmployeeDetails(String name, String designation, String reportingTo,String userType, String address, String gender,
		String yearsOfService, long bankAccount, long ctc, int leaves, EmployeeLogin empLoginDetails) {
	super();
	this.name = name;
	this.designation = designation;
	this.reportingTo = reportingTo;
	this.userType=userType;
	this.address = address;
	this.gender = gender;
	this.yearsOfService = yearsOfService;
	this.bankAccount = bankAccount;
	this.ctc = ctc;
	this.leaves = leaves;
	this.empLoginDetails = empLoginDetails;
}

public EmployeeDetails(String name, String designation, String reportingTo,String userType, String address, String gender,
		String yearsOfService, long bankAccount, long ctc, int leaves, EmployeeLogin empLoginDetails,
		List<Attendance> attendances, Salary salary) {
	super();
	this.name = name;
	this.designation = designation;
	this.reportingTo = reportingTo;
	this.userType=userType;
	this.address = address;
	this.gender = gender;
	this.yearsOfService = yearsOfService;
	this.bankAccount = bankAccount;
	this.ctc = ctc;
	this.leaves = leaves;
	this.empLoginDetails = empLoginDetails;
	this.attendances = attendances;
	this.salary = salary;
}






public long getEmp_id() {
	return emp_id;
}

public void setEmp_id(long emp_id) {
	this.emp_id = emp_id;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public String getDesignation() {
	return designation;
}


public void setDesignation(String designation) {
	this.designation = designation;
}


public String getReportingTo() {
	return reportingTo;
}


public void setReportingTo(String reportingTo) {
	this.reportingTo = reportingTo;
}


public String getAddress() {
	return address;
}


public void setAddress(String address) {
	this.address = address;
}


public String getGender() {
	return gender;
}


public void setGender(String gender) {
	this.gender = gender;
}


public String getYearsOfService() {
	return yearsOfService;
}


public void setYearsOfService(String yearsOfService) {
	this.yearsOfService = yearsOfService;
}


public long getBankAccount() {
	return bankAccount;
}


public void setBankAccount(long bankAccount) {
	this.bankAccount = bankAccount;
}


public long getCtc() {
	return ctc;
}


public void setCtc(long ctc) {
	this.ctc = ctc;
}


public int getLeaves() {
	return leaves;
}


public void setLeaves(int leaves) {
	this.leaves = leaves;
}


public EmployeeLogin getEmpLoginDetails() {
	return empLoginDetails;
}


public void setEmpLoginDetails(EmployeeLogin empLoginDetails) {
	this.empLoginDetails = empLoginDetails;
}


public List<Attendance> getAttendances() {
	return attendances;
}


public void setAttendances(List<Attendance> attendances) {
	this.attendances = attendances;
}


public Salary getSalary() {
	return salary;
}


public void setSalary(Salary salary) {
	this.salary = salary;
}






public String getUserType() {
	return userType;
}






public void setUserType(String userType) {
	this.userType = userType;
}

}
